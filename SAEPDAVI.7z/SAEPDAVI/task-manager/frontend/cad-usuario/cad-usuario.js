const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const cors = require('cors');  // Importando o cors
const app = express();
const port = 3000;

// Permitir requisições de qualquer origem
app.use(cors());  // Habilitando CORS para todas as origens

// Configuração do banco de dados
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root', // seu usuário do MySQL
    password: '', // sua senha do MySQL
    database: 'kanban'
});

// Conectar ao banco de dados
db.connect(err => {
    if (err) {
        console.error('Erro ao conectar ao banco de dados:', err);
        return;
    }
    console.log('Conectado ao banco de dados');
});

// Middleware para parsear JSON
app.use(bodyParser.json());

// Rota para cadastrar o usuário
app.post('/usuarios', (req, res) => {
    const { nome, email } = req.body;

    if (!nome || !email) {
        return res.status(400).send({ error: 'Nome e e-mail são obrigatórios' });
    }

    // Inserir usuário no banco de dados
    const query = 'INSERT INTO usuarios (nome, email) VALUES (?, ?)';
    db.query(query, [nome, email], (err, result) => {
        if (err) {
            return res.status(500).send({ error: 'Erro ao cadastrar usuário' });
        }
        res.status(201).send({ message: 'Usuário cadastrado com sucesso!' });
    });
});

// Iniciar o servidor
app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});
