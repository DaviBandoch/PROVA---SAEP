const express = require('express');
const { Pool } = require('pg'); // Biblioteca para PostgreSQL

const app = express();
app.use(express.json()); // Para interpretar dados JSON enviados nas requisições

// Configuração do banco de dados
const pool = new Pool({
  user: 'seu_usuario',       // Substitua pelo nome do seu usuário do PostgreSQL
  host: 'localhost',
  database: 'task_manager',  // Substitua pelo nome do seu banco de dados
  password: 'sua_senha',     // Substitua pela senha do seu banco
  port: 5432,
});

// Rota de cadastro de usuário
app.post('/usuarios', async (req, res) => {
  const { nome, email } = req.body;
  
  if (!nome || !email) {
    return res.status(400).send('Nome e e-mail são obrigatórios');
  }

  try {
    const result = await pool.query(
      'INSERT INTO usuarios (nome, email) VALUES ($1, $2) RETURNING *',
      [nome, email]
    );
    res.status(201).json(result.rows[0]); // Retorna o usuário cadastrado
  } catch (error) {
    console.error(error);
    res.status(500).send('Erro ao cadastrar o usuário');
  }
});

// Inicia o servidor
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
